/*
 * DO NOT MAKE ANY CHANGES
 */

#include "book_romance.h"

bool BookRomance::mercy_rule_apply() {
    return false;
}
